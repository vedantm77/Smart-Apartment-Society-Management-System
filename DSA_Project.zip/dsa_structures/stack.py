"""
Stack Implementation (LIFO - Last In First Out)
Real-world use: Billing history with undo functionality
Time Complexity: Push O(1), Pop O(1)
Space Complexity: O(n)
"""

class Stack:
    """
    Stack for managing billing operations
    Why LIFO? Most recent bill is first to be undone
    Real-world: Undo last billing entry if mistake made
    """
    def __init__(self):
        self.items = []  # List to store bills
    
    def push(self, item):
        """
        Add bill to top of stack
        Time Complexity: O(1)
        Real-world: New bill entry added
        """
        self.items.append(item)
        return True
    
    def pop(self):
        """
        Remove and return most recent bill
        Time Complexity: O(1)
        Real-world: Undo last bill (if wrong amount entered)
        """
        if self.is_empty():
            return None
        return self.items.pop()
    
    def peek(self):
        """
        View top bill without removing
        Time Complexity: O(1)
        Real-world: Check last bill entered
        """
        if self.is_empty():
            return None
        return self.items[-1]
    
    def is_empty(self):
        """Check if no bills exist"""
        return len(self.items) == 0
    
    def size(self):
        """Return total number of bills"""
        return len(self.items)
    
    def get_all(self):
        """
        Get all bills (most recent first)
        Real-world: Display billing history
        """
        return self.items[::-1]  # Reverse to show newest first
    
    def clear(self):
        """Clear entire billing history"""
        self.items = []
