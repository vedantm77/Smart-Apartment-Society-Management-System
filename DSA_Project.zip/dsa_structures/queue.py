"""
Queue Implementation (FIFO - First In First Out)
Real-world use: Visitor entry management at society gate
Time Complexity: Enqueue O(1), Dequeue O(1)
Space Complexity: O(n)
"""

class Queue:
    """
    Queue for managing visitor entries
    Why FIFO? First visitor to arrive is first to be processed
    Real-world analogy: Standing in line at society gate
    """
    def __init__(self):
        self.items = []  # List to store visitors
    
    def enqueue(self, item):
        """
        Add visitor to end of queue
        Time Complexity: O(1)
        Real-world: New visitor arrives at gate
        """
        self.items.append(item)
        return True
    
    def dequeue(self):
        """
        Remove and return first visitor in queue
        Time Complexity: O(n) due to list.pop(0), but conceptually O(1)
        Real-world: Process visitor entry and allow them in
        Note: In production, use collections.deque for true O(1)
        """
        if self.is_empty():
            return None
        return self.items.pop(0)
    
    def peek(self):
        """
        View first visitor without removing
        Time Complexity: O(1)
        Real-world: Check who's next at the gate
        """
        if self.is_empty():
            return None
        return self.items[0]
    
    def is_empty(self):
        """Check if visitor queue is empty"""
        return len(self.items) == 0
    
    def size(self):
        """Return number of visitors waiting"""
        return len(self.items)
    
    def get_all(self):
        """
        Get all visitors in queue
        Real-world: Display all pending visitor entries
        """
        return self.items.copy()
    
    def clear(self):
        """Empty the entire queue"""
        self.items = []
