"""
Complaint Service Layer
Business logic for complaint management using Min Heap (Priority Queue)
"""

import json
import os
from dsa_structures.heap import MinHeap


class ComplaintService:
    """
    Service layer for complaint operations
    Uses Min Heap for priority-based resolution
    """
    def __init__(self, data_dir):
        self.data_dir = data_dir
        self.complaints_file = os.path.join(data_dir, 'complaints.json')
        
        # Initialize Min Heap
        self.complaint_heap = MinHeap()
        
        # Load existing data
        self.load_data()
    
    def load_data(self):
        """Load complaints from JSON file"""
        if os.path.exists(self.complaints_file):
            with open(self.complaints_file, 'r') as f:
                complaints = json.load(f)
                for complaint in complaints:
                    self.complaint_heap.insert(complaint)
    
    def save_complaints(self):
        """Save complaints to JSON file"""
        complaints = self.complaint_heap.get_all()
        with open(self.complaints_file, 'w') as f:
            json.dump(complaints, f, indent=2)
    
    def add_complaint(self, complaint_data):
        """Add complaint using Min Heap (insert)"""
        self.complaint_heap.insert(complaint_data)
        self.save_complaints()
        return True
    
    def resolve_complaint(self):
        """Resolve highest priority complaint using Min Heap (extract min)"""
        complaint = self.complaint_heap.extract_min()
        if complaint:
            self.save_complaints()
        return complaint
    
    def get_all(self):
        """Get all complaints sorted by priority"""
        return self.complaint_heap.get_all()
    
    def get_count(self):
        """Get total complaint count"""
        return self.complaint_heap.size()
    
    def peek_top_priority(self):
        """View highest priority complaint without removing"""
        return self.complaint_heap.peek()
    
    def initialize_sample_data(self):
        """Initialize with sample data if file doesn't exist"""
        if not os.path.exists(self.complaints_file):
            sample_complaints = [
                {'title': 'Water Leakage', 'flat': 'A-101', 'priority': 1, 'desc': 'Ceiling leaking in bedroom', 'time': '10:30 AM'},
                {'title': 'Elevator Issue', 'flat': 'B-201', 'priority': 2, 'desc': 'Elevator stuck on 3rd floor', 'time': '11:45 AM'},
                {'title': 'Garden Maintenance', 'flat': 'Common', 'priority': 3, 'desc': 'Garden needs trimming', 'time': '02:15 PM'}
            ]
            for complaint in sample_complaints:
                self.complaint_heap.insert(complaint)
            self.save_complaints()
